package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class busActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus);
    }
    public void appeler(View view) {
        Uri tel=Uri.parse("tel:92969509");
        Intent appeler_itent=new Intent(Intent.ACTION_VIEW,tel);
        startActivity(appeler_itent);
    }


}